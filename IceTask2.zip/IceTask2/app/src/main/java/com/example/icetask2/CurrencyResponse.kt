package com.example.icetask2

data class CurrencyResponse(
    val base: String,
    val rates: Map<String, Double>
)