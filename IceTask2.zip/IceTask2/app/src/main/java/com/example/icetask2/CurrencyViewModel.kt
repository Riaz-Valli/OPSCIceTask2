package com.example.icetask2

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class CurrencyViewModel : ViewModel() {

    private val _conversionRate = MutableLiveData<Double>()
    val conversionRate: LiveData<Double> = _conversionRate

    fun getExchangeRate(baseCurrency: String, targetCurrency: String) {
        val service = RetrofitClient.getApiService()
        service.getExchangeRates(baseCurrency).enqueue(object : Callback<CurrencyResponse> {
            override fun onResponse(
                call: Call<CurrencyResponse>,
                response: Response<CurrencyResponse>
            ) {
                if (response.isSuccessful) {
                    response.body()?.let { currencyResponse ->
                        _conversionRate.value = currencyResponse.rates[targetCurrency]
                    }
                }
            }

            override fun onFailure(call: Call<CurrencyResponse>, t: Throwable) {
            }
        })
    }
}
